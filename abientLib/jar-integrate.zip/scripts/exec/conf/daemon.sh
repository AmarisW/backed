#!/bin/bash
# description: jarapps spring-hello.jar

export JAVA_HOME="/usr/java/default"
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=./:${CLASSPATH}

JAR_HOME="/linkcld/jarapps/asdzxc-63315"
JAR_FILE="/linkcld/jarapps/asdzxc-63315/spring-hello.jar"
# APM_ENABLE=false
# if ${APM_ENABLE} ; then
APM_OPTS="-javaagent:/linkcld/installs/apm/skywalking-agent/skywalking-agent.jar -Dskywalking.agent.service_name=asdzxc-63315 -Dskywalking.logging.dir=./logs"
# fi
JAVA_OPTS="-server -Xms512m -Xmx512m -Djava.security.egd=file:///dev/urandom -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=./logs/heapdump.hprof"

service_name="asdzxc-63315"
key_word="/asdzxc-63315/spring-hello.jar"
PIDFile="$JAR_HOME/pid/$service_name"_pid
cd $(dirname $0)/..

if [ ! -d $JAR_HOME ];then
    echo "Error:\$JAR_HOME isn't exist"
    exit 1
fi

start() {
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -n "$pid" ];then
        echo $pid | tee $PIDFile &> /dev/null
        echo -e "${service_name}(`echo ${pid}`) [\033[32m started \033[0m]"
        return 2;
    else
        echo "starting ${service_name}......"
        nohup java ${APM_OPTS} ${JAVA_OPTS} -jar ${JAR_FILE} &> /dev/null &
    fi

    sleep 2
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -n "$pid" ];then
        echo $pid | tee $PIDFile &> /dev/null
        echo -e "start ${service_name}(`echo ${pid}`) [\033[32m OK \033[0m]"
    else
        echo -e "start ${service_name}(`echo ${pid}`) [\033[31m Failed \033[0m]"
    fi
}


stop() {
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -z "$pid" ];then
        echo "No ${service_name} running"
    else
        echo -e "Send shutdown request to ${service_name}(`echo ${pid}`)\c"
        kill ${pid}
        oldpid=${pid}
        t=1
        while [ ${oldpid} ];do
            oldpid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
            echo -e '!\c'
            sleep 1
            let t++
            if [ $t -gt 20 ];then
                kill -9 ${oldpid} &> /dev/null
                sleep 2
            fi
        done
        echo -e "\nSend shutdown request to ${service_name}(`echo ${pid}`) [\033[32m OK \033[0m]"
    fi
    rm -f $PIDFile
}

status() {
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -z "$pid" ];then
        echo -e "The ${service_name} is [\033[32m stopped \033[0m]"
    else
        echo -e "The ${service_name}(`echo ${pid}`) is [\033[32m running \033[0m]"
    fi
}

case $1 in
start)
    start
    ;;
stop)
    stop
    ;;
restart)
    stop
    sleep 2
    start
    ;;
status)
    status
    ;;
*)
    echo -e "\033[31mError:usage like this: \033[0m\n\033[32mservice $(basename $0) start|stop|restart|status\033[0m or \033[32m$0 start|stop|restart|status\033[0m"
    ;;
esac
