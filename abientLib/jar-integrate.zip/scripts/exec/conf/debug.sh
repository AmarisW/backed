#!/bin/bash
# description: debug script for spring-hello.jar

export JAVA_HOME="/usr/java/default"
export PATH=$JAVA_HOME/bin:$PATH

JAR_HOME="/linkcld/jarapps/asdzxc-63315"
JAR_FILE="/linkcld/jarapps/asdzxc-63315/spring-hello.jar"
JAVA_OPTS="-Xms512m -Xmx512m -Djava.security.egd=file:///dev/urandom -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=../logs/heapdump.hprof"
service_name="asdzxc-63315"
key_word="asdzxc-63315/spring-hello.jar"
admin="bootapp"
PIDFile=$JAR_HOME/pid

if [ ! -d $JAR_HOME ];then
    echo "Error:\$JAR_HOME isn't exist"
    exit 1
fi

start() {
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -n "$pid" ];then
        echo $pid |sudo tee $PIDFile &> /dev/null
        sudo chown ${admin}.${admin} $PIDFile &> /dev/null
        echo -e "${service_name}(`echo ${pid}`) [\033[32m started \033[0m]"
        return 2;
    else
        echo "starting ${service_name}......"
        sudo runuser $admin -s /bin/bash -c "cd ${JAR_HOME}; nohup java -jar ${JAVA_OPTS} ${JAR_FILE} >${JAR_HOME}/logs/debug.log 2>&1 &"
    fi

    sleep 2
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -n "$pid" ];then
        echo $pid |sudo tee $PIDFile &> /dev/null
        sudo chown ${admin}.${admin} $PIDFile &> /dev/null
        echo -e "start ${service_name}(`echo ${pid}`) [\033[32m OK \033[0m]"
    else
        echo -e "start ${service_name}(`echo ${pid}`) [\033[31m Failed \033[0m]"
    fi
}


stop() {
    pid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
    if [ -z "$pid" ];then
        echo "No ${service_name} running"
    else
        echo -e "Send shutdown request to ${service_name}(`echo ${pid}`)\c"
        sudo kill ${pid}
        oldpid=${pid}
        t=1
        while [ ${oldpid} ];do
            oldpid=$(ps -ef|grep -v grep|grep $key_word|awk '{print $2}')
            echo -e '!\c'
            sleep 0.5
            let t++
            if [ $t -gt 30 ];then
                sudo kill -9 ${oldpid} &> /dev/null
                sleep 0.5
            fi
        done
        echo -e "\nSend shutdown request to ${service_name}(`echo ${pid}`) [\033[32m OK \033[0m]"
    fi
    sudo rm -f $PIDFile
}


case $1 in
''|start)
    start
    ;;
stop)
    stop
    ;;
*)
    echo -e "\033[31mError:usage like this: \033[0m\n\033[32$JAR_HOME/debug_startup.sh start|stop\033[0m"
    ;;
esac
