#!/bin/bash
# Version: 1.1.3

# vars
jar_full_path=""
bakJarMaxNum=10
service_name=""
service_file=""
jar_file=""
service_registration_file=""


if [ -z "$jar_full_path" -o -z "$bakJarMaxNum" -o -z "$service_name" -o -z "$service_file" -o -z "$jar_file"  -o -z "$service_registration_file" ]; then
    echo "Error: ./main.sh's vars jar_full_path, bakJarMaxNum, service_name, service_file, jar_file, service_registration_file is null. please set vars first"
    exit 1
fi

if [ ! -x /usr/bin/sudo ]; then
    echo "Error: command /usr/bin/sudo isn't existed"
    exit 1
fi

if sudo -l &> /dev/null; then
    :
else
    echo "Error: you must switch root or sudo user"
    exit 1
fi

if [ ! -f ./bin/exec.sh ]; then
    echo "Error: bin/exec.sh isn't existed"
    exit 1
elif ! sudo chmod 755 ./bin/exec.sh; then
    echo "Error: you must switch root or sudo user"
    exit 1
fi

./bin/exec.sh "$jar_full_path" "$bakJarMaxNum" "$service_name" "$service_file" "$jar_file" "$service_registration_file"
exit $?
