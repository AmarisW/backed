#!/bin/bash
#
./main.sh <<<5
