#!/bin/bash
#
./main.sh <<<1
