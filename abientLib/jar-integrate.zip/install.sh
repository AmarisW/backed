#!/bin/bash
# Version: 1.1.3

if [ ! -x /usr/bin/sudo ]; then
    echo "Error: command /usr/bin/sudo isn't existed"
    exit 1
fi

if sudo -l &> /dev/null; then
    :
else
    echo "Error: you must switch root or sudo user"
    exit 1
fi

# if ! uname -r|egrep -sq "\.aarch64$|\.x86_64"; then
#     echo "Error: the os architecture isn't aarch64 or x86_64" 
#     exit 1
# fi

if [ ! -f ./scripts/bin/exec.sh ]; then
    echo "Error: ./scriptsbin/exec.sh isn't existed"
    exit 1
elif ! sudo chmod 755 ./scripts/bin/exec.sh; then
    echo "Error: you must switch root or sudo user"
    exit 1
fi
sudo cp -a ./scripts/exec/conf ./scripts/
sudo chmod 755 ./scripts/{bin,conf,software} &>/dev/null

./scripts/bin/exec.sh
